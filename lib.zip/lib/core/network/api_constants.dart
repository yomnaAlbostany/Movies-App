class ApiConstants {
  static const baseUrl = 'https://api.themoviedb.org/3/';
  static const apiKey =
      'eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiIyNDJjNWYyZmFiYWI1Njc4MTljODQwYzA1ZDNhNTg4MCIsIm5iZiI6MTY4NDE5MzgzMS43ODMsInN1YiI6IjY0NjJjMjI3YTY3MjU0MDEwMTBhODUzYSIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.zTpO0PPmxvU8tEPGU3eB79WlG9ULVDytW80fthHa79U';
  static const trending = 'trending/movie/day';
  static const nowPlaying = 'movie/now_playing';
  static const topRated = 'movie/top_rated';
  static const upcoming = 'movie/upcoming';
  static const serach = 'search/movie';
}
