import 'dart:ui';

class AppColor {
  static const primaryColor = Color(0xffEB2F3D);
  static const backgroundColor = Color(0xff1F1F1F);
}
