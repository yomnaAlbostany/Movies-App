class Routes {
  static const splash = '/splash';
  static const onBording = '/on_bording';
  static const home = '/home';
  static const movieDetails = '/movie_details';
}
